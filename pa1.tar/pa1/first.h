#ifndef FIRST_H_
#define FIRST_H_

int main(int argc, char** argv);

#endif

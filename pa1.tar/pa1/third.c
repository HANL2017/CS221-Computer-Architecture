#include<stdio.h>
#include<stdlib.h>
#include "third.h"

void sort(int num){
  struct node *temp, *right;
  temp = (struct node *) malloc(sizeof(struct node));
  temp->data=num;
  right = (struct node *) head;
  while(right->next != NULL){
    right = right->next;
  }
  right->next = temp;
  right = temp;
  right->next = NULL;
}

void add(int num){
  struct node *temp;
  temp = (struct node *) malloc(sizeof(struct node));
  temp->data=num;
  if (head == NULL){
    head = temp;
    head->next = NULL;
  }else{
    temp->next = head;
    head = temp;
  }
}

void addloc(int num, int loc){
  int i;
  struct node *temp, *left, *right;
  right = head;
  for(i = 1; i < loc; i++){
    left = right;
    right = right->next;
  }
  temp = (struct node *) malloc(sizeof(struct node));
  temp->data = num;
  left->next = temp;
  left = temp;
  left->next = right;
  return;
}
void insert(int num){
  int c = 0;
  struct node *temp;
  temp = head;
  if (temp == NULL){
    add(num);
  }else{
    while(temp != NULL){
      if (temp->data < num){
        c++;
        temp = temp->next;
      }else if (temp->data == num){
        return;
      }else{
        break;
      }
    }
    if (c == 0){
      add(num);
    }else if (c < count()){
      addloc(num, ++c);
    }
    else{
      sort(num);
    }
  }
}

int delete(int num){
  struct node *temp, *prev;
  temp = head;
  while(temp!= NULL){
    if (temp->data == num){
      if (temp == head){
        head = temp->next;
        free(temp);
        return 1;
      }
      else{
        prev->next = temp->next;
        free(temp);
        return 1;
      }
    }else{
      prev = temp;
      temp = temp->next;
    }
  }
  return 0;
}

void  result(struct node *r){
  r=head;
  if (r==NULL){
    printf("\n");
    return;
  }
  while(r!=NULL){
    printf("%d\t",r->data);
    r=r->next;
  }
  printf("\n");
}

int count(){
  struct node *n;
  int c=0;
  n=head;
  while (n!=NULL){
    n=n->next;
    c++;
  }
  return c;
}

int main(int argc, char** argv){
  FILE* file;
  int num;
  char operator;
  struct node *n;
  n = (struct node *) malloc(sizeof(struct node));
  head = NULL;
  if(argc != 2){
    printf("error\n");
    return 0;
  }
  file = fopen(argv[1], "r");
  if(file == NULL){
    printf("error\n");
    return 0;
  }
  while (fscanf(file, "%c\t%d\n", &operator, &num)!= EOF){
    if (operator == 'i'){
      insert(num);
    }else if (operator == 'd'){
      delete(num);
    }else{
      printf("error\n");
      exit(0);
    }
  }
  result(n);
  return 0;
}





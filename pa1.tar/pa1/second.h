#ifndef SECOND_H_
#define SECOND_H_

int main(int argc, char** argv);

#endif

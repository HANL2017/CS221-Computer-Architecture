#include<stdio.h>
#include<stdlib.h>
#include "second.h"
int main(int argc, char** argv){
  int a;
  int i = 2;
  int prime = 0;
  if (argc != 2){
    printf("error\n");
    return 0;
  }
  a = (int) strtol(argv[1], NULL, 10);
  if (a < 2){
    printf("no\n");
  }else if (a == 2){
    printf("yes\n");
  }else{
    while (i < a){
      if (a%i == 0){
        prime = 1;
        break;
      }else{
        prime = 0;
      }
      i++;
    }
    if (prime == 0){
      printf("yes\n");
    }else{
      printf("no\n");
    }
  }
  return 0;
}

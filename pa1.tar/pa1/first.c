#include<stdio.h>
#include<stdlib.h>
#include "first.h"
int main(int argc, char **argv){
  int a;
  if (argc != 2){
    printf("error\n");
    return 0;
  }
  a = (int)strtol (argv[1],NULL,10);
  if (a%2 == 0){
    printf("even\n");
  }else{
    printf("odd\n");
  }
  return 0;
}

#ifndef FOURTH_H_
#define FOURTH_H_

struct node{
  int data;
  struct node *next;
}*head;

void sort (int num);
void add (int num);
void addloc (int num, int loc);
void search (int num);
int count();

#endif

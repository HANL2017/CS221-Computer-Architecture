#include<stdio.h>
#include<stdlib.h>

int main(int argc, char** argv)
{
  FILE* file;
  int row, col;
  int i, j;
  int** matrix;
  int** result;
  if(argc != 2)
    {
      printf("error\n");
      return 0;
    }
  file = fopen(argv[1], "r");
  if(file == NULL)
    {
      printf("file does not exist\n");
      return 0;
    }
  fscanf(file, "%d\t%d\n", &row, &col);
  matrix = (int **) malloc(sizeof(int*)* ((2*row)+1));
  result = (int **) malloc(sizeof(int*)* row);
  for(i = 0; i < row; i++)
    {
      matrix[i] = (int*) malloc(sizeof(int) * col);
      for(j = 0; j < col ; j++)
        {
          int temp;
          fscanf(file, "%d", &temp);
          matrix[i][j] = temp;
        }
      fscanf(file, "\n");
    }
  for(i = row; i < row + row; i++)
    {
      matrix[i] = (int*) malloc(sizeof(int) * col);
      for(j = 0; j < col ; j++)
        {
          int temp;
          fscanf(file, "%d", &temp);
          matrix[i][j] = temp;
        }
      fscanf(file, "\n");
    }
  for(i = 0; i < row; i++)
    {
      result[i] = (int*) malloc(sizeof(int) * col);
      for(j = 0; j < col ; j++)
        {

          result[i][j] = matrix[i][j] + matrix[i+row][j] ;
        }

    }

  for(i = 0; i < row; i++)
    {
      for(j = 0; j < col; j++)
        {
          printf("%d\t ", result[i][j]);
        }
      printf("\n");
    }
  printf("\n");
  for(i = 0; i < row; i++)
    {
      free(matrix[i]);
    }

  for(i = 0; i < row; i++)
    {
      free(result[i]);
    }
  free(matrix);
  free(result);
  fclose(file);
  return 0;
}



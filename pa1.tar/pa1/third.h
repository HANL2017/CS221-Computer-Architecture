#ifndef THIRD_H_
#define THIRD_H_

struct node{
  int data;
  struct node *next;
}*head;

void sort (int num);
void add (int num);
void addloc (int num, int loc);
int delete (int num);
void result (struct node *r);
int count();

#endif

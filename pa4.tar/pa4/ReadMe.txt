FIFO replacement policy is not implemented. It will take the argument perfectly but will only process in LRU algorithm.

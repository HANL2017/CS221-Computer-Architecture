#ifndef COUNT_H_
#define COUNT_H_
struct node {
  size_t data;
  struct node* next;
};
int Hash(size_t);
#define size 1000
struct node *HashTable[size];
#endif

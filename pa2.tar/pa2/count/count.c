#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include "count.h"

int main(int argc, char** argv){
  int count;
  size_t decimal;
  FILE *file;
  if (argc != 2){
    printf("error\n");
    exit(0);
  }
  file = fopen(argv[1], "r");
  if (file == NULL){
    printf("error\n");
    exit(0);
  }
  for (count = 0; count < size; count++){
    HashTable[count] = NULL;
  }
  count = 0;
  while (fscanf(file, "%lx", &decimal) != EOF){
    count += Hash(decimal);
  }
  fclose(file);
  printf("%d\n", count);
  return 0;
}

int Hash(size_t decimal){
  int index;
  struct node *ptr, *prev;
  if (decimal == -1){
    return 0;
  }
  index = decimal % size;
  ptr = HashTable[index]; 
  if (HashTable[index] == NULL){
    HashTable[index] = (struct node*) malloc(sizeof(struct node));
    HashTable[index]->data = decimal;
    HashTable[index]->next = NULL;
    return 1;
  }
  while (ptr != NULL){ 
    if(ptr->data == decimal)
      return 0;
    prev = ptr;
    ptr = ptr->next;
  }
  prev->next = (struct node*) malloc(sizeof(struct node));
  prev = prev->next;
  prev->data = decimal;
  prev->next = NULL;
  return 1;
}
